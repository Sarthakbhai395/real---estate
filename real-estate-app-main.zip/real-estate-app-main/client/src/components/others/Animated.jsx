import Spline from '@splinetool/react-spline';

export default function App() {
  return (
    <Spline scene="https://prod.spline.design/3n9KUcynNstJ5f75/scene.splinecode" />
  );
}
